#!/system/bin/sh
# Init.d test
# By Siddharth_Sarkar
#busybox mount -o remount,rw -t auto /system
#busybox mount -o remount,rw -t auto /data
echo 1 > /sys/devices/soc/leds-qpnp-9/leds/button-backlight/brightness
sleep 3
while true
do
if dumpsys input | grep "Last Raw Touch: pointerCount=1"; then
	echo 1 > /sys/devices/soc/leds-qpnp-9/leds/button-backlight/brightness && sleep 3
	else
    echo 0 > /sys/devices/soc/leds-qpnp-9/leds/button-backlight/brightness
    fi
done
